@echo off
chcp 65001 >nul
reg delete "HKCU\Software\Classes\mwfolder" /f >nul 2>nul
rmdir /S /Q "%LOCALAPPDATA%\MyWorklist" 2>nul
echo  폴더 열기 도우미를 지웠어요.
echo.
pause
