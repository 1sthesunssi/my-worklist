﻿# My Worklist 폴더 열기 도우미
# 앱이 보내 준 주소(mwfolder:...)에서 폴더 경로를 꺼내 탐색기로 엽니다.
# 안전장치: 내 PC의 드라이브 경로(예: C:\...)만 열고, 프로그램은 절대 실행하지 않습니다.
param([string]$u)
try {
  $p = $u -replace '^mwfolder:(//)?', ''
  $p = [uri]::UnescapeDataString($p).Trim().Trim('"')
  $p = $p.TrimEnd('\')
  if ($p -match '^[A-Za-z]:$') { $p = $p + '\' }
  if ($p -match '^[A-Za-z]:\\' -and $p -notmatch '[<>|*?"]') {
    if (Test-Path -LiteralPath $p -PathType Container) {
      if ($p -match '^[A-Za-z]:\\$') { $a = $p } else { $a = '"' + $p + '"' }
      Start-Process -FilePath 'explorer.exe' -ArgumentList $a
    }
    elseif (Test-Path -LiteralPath $p -PathType Leaf) {
      # 파일이면 실행하지 않고, 그 폴더를 열면서 파일을 선택만 해 줍니다.
      Start-Process -FilePath 'explorer.exe' -ArgumentList ('/select,"' + $p + '"')
    }
    else {
      $parent = Split-Path -LiteralPath $p -Parent
      if ($parent -and (Test-Path -LiteralPath $parent -PathType Container)) {
        Start-Process -FilePath 'explorer.exe' -ArgumentList ('"' + $parent + '"')
      }
    }
  }
} catch { }
