' My Worklist folder opener (v2.3: fast, no PowerShell, no folder check for extension-less names)
' Receives mwfolder:<hex of UTF-16 chars>. Opens only local drive paths (C:\...) in Explorer.
' Never runs files: a file path only gets selected inside its folder.
Option Explicit
Function HexVal(s)
  Dim k, d, r
  r = 0
  For k = 1 To Len(s)
    d = InStr("0123456789ABCDEF", UCase(Mid(s, k, 1))) - 1
    If d < 0 Then d = 0
    r = r * 16 + d
  Next
  HexVal = r
End Function
Dim sh, fso, a, h, p, i, re, par
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
If WScript.Arguments.Count = 0 Then WScript.Quit
a = WScript.Arguments(0)
Set re = New RegExp
re.IgnoreCase = True
re.Pattern = "^mwfolder:/*([0-9a-f]+)$"
If Not re.Test(a) Then WScript.Quit
h = re.Execute(a)(0).SubMatches(0)
If Len(h) Mod 4 <> 0 Or Len(h) > 8000 Then WScript.Quit
p = ""
For i = 1 To Len(h) Step 4
  p = p & ChrW(HexVal(Mid(h, i, 4)))
Next
p = Trim(p)
re.Pattern = "^[A-Za-z]:\\"
If Not re.Test(p) Then WScript.Quit
re.Pattern = "[<>|*?""]"
If re.Test(p) Then WScript.Quit
Do While Len(p) > 3 And Right(p, 1) = "\"
  p = Left(p, Len(p) - 1)
Loop
Dim fe, nm
nm = Mid(p, InStrRev(p, "\") + 1)
re.Pattern = "\.[A-Za-z0-9]{1,5}$"
If Len(p) <= 3 Then
  fe = True
ElseIf Not re.Test(nm) Then
  fe = True  ' name has no file extension: treat as folder, open at once (fast on Google Drive)
Else
  fe = fso.FolderExists(p)  ' looks like a file: check first, never run it
End If
If fe Then
  If Len(p) = 3 Then
    sh.Run "explorer.exe " & p, 1, False
  Else
    sh.Run "explorer.exe """ & p & """", 1, False
  End If
ElseIf fso.FileExists(p) Then
  sh.Run "explorer.exe /select,""" & p & """", 1, False
Else
  par = fso.GetParentFolderName(p)
  If par <> "" Then
    If fso.FolderExists(par) Then sh.Run "explorer.exe """ & par & """", 1, False
  End If
End If
