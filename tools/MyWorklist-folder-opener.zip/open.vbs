' My Worklist folder opener (fast: no PowerShell)
' Receives mwfolder:<hex of UTF-16 chars>. Opens only local drive paths (C:\...) in Explorer.
' Never runs files: a file path only gets selected inside its folder.
Option Explicit
Dim sh, fso, a, h, p, i, re, par
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
If WScript.Arguments.Count = 0 Then WScript.Quit
a = WScript.Arguments(0)
Set re = New RegExp
re.IgnoreCase = True
re.Pattern = "^mwfolder:/*([0-9a-f]+)$"
If Not re.Test(a) Then WScript.Quit
h = re.Execute(a)(0).SubMatches(0)
If Len(h) Mod 4 <> 0 Or Len(h) > 8000 Then WScript.Quit
p = ""
For i = 1 To Len(h) Step 4
  p = p & ChrW(CLng("&H" & Mid(h, i, 4) & "&"))
Next
p = Trim(p)
re.Pattern = "^[A-Za-z]:\\"
If Not re.Test(p) Then WScript.Quit
re.Pattern = "[<>|*?""]"
If re.Test(p) Then WScript.Quit
Do While Len(p) > 3 And Right(p, 1) = "\"
  p = Left(p, Len(p) - 1)
Loop
If fso.FolderExists(p) Then
  If Len(p) = 3 Then
    sh.Run "explorer.exe " & p, 1, False
  Else
    sh.Run "explorer.exe """ & p & """", 1, False
  End If
ElseIf fso.FileExists(p) Then
  sh.Run "explorer.exe /select,""" & p & """", 1, False
Else
  par = fso.GetParentFolderName(p)
  If par <> "" Then
    If fso.FolderExists(par) Then sh.Run "explorer.exe """ & par & """", 1, False
  End If
End If
