' My Worklist folder opener - runs open.ps1 hidden (no black window flash)
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
If WScript.Arguments.Count > 0 Then
  dir = fso.GetParentFolderName(WScript.ScriptFullName)
  arg = Replace(WScript.Arguments(0), """", "")
  sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & dir & "\open.ps1"" """ & arg & """", 0, False
End If
