@echo off
chcp 65001 >nul
echo.
echo  My Worklist - 폴더 열기 도우미 설치
echo  ------------------------------------
if not exist "%~dp0open.vbs" (
  echo  [!] 압축을 먼저 풀어 주세요. 압축 파일 안에서 바로 실행하면 안 돼요.
  echo.
  pause
  exit /b 1
)
set "DEST=%LOCALAPPDATA%\MyWorklist"
mkdir "%DEST%" 2>nul
copy /Y "%~dp0open.vbs" "%DEST%\open.vbs" >nul
del "%DEST%\open.ps1" 2>nul
reg add "HKCU\Software\Classes\mwfolder" /ve /d "URL:My Worklist Folder" /f >nul
reg add "HKCU\Software\Classes\mwfolder" /v "URL Protocol" /d "" /f >nul
reg add "HKCU\Software\Classes\mwfolder\shell\open\command" /ve /d "wscript.exe \"%DEST%\open.vbs\" \"%%1\"" /f >nul
if errorlevel 1 (
  echo  [!] 설치하지 못했어요.
) else (
  echo  설치가 끝났어요!
  echo  이제 My Worklist에서 폴더를 누르면 탐색기가 바로 열려요.
  echo  처음 한 번은 브라우저가 "열까요?" 하고 물어요. "항상 허용"을 골라 주세요.
)
echo.
pause
